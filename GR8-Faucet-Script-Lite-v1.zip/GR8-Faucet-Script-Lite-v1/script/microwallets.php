<?php

// Microwallets Data - Be careful when editing this array
$microwallets = [
    // https://cedsonhub.site/api-docs
    'cedsonhub' => [
        'name' => 'CedsonHub',
        'currencies' => ['BTC','LTC','DOGE'],
        'api_base' => 'https://cedsonhub.site/api/v1/',
        'check' => 'https://cedsonhub.site/microwallet-service/balance',
        'url' => 'https://gr8.cc/goto/cedsonhub',
        'placeholder' => 'Enter your CedsonHub Username'
    ],
    // https://cryptoo.me/api-doc/
    'cryptoo' => [
        'name' => 'Cryptoo',
        'currencies' => ['BTC'],
        'api_base' => 'https://cryptoo.me/api/v1/',
        'check' => 'https://cryptoo.me/check/{address}',
        'url' => 'https://gr8.cc/goto/cryptoo'
    ],
    // https://expresscrypto.io/account/site-owner/panel/documentation
    'expresscrypto' => [ 
        'name' => 'ExpressCrypto',
        'currencies' => ['BTC','BCH','BCN','DASH','DGB','DOGE','ETH','EXG','EXS','LSK','LTC','NEO','POT','PPC','STRAT','TRX','WAVES','XMR','XRP','ZEC'],
        'api_base' => 'https://expresscrypto.io/public-api/v2/',
        'check' => 'https://expresscrypto.io/dashboard',
        'url' => 'https://gr8.cc/goto/expresscrypto',
        'placeholder' => 'Enter your Unique ExpressCrypto ID'
    ],
    // https://www.faucetfly.com/bitcoin-micropayment-api-docs
    'faucetfly' => [
        'name' => 'FaucetFly',
        'currencies' => ['BTC','ETH'],
        'api_base' => 'https://www.faucetfly.com/api/v1/',
        'check' => 'https://www.faucetfly.com/check/{address}',
        'url' => 'https://gr8.cc/goto/faucetfly',
    ],
    // https://faucetpay.io/page/api-documentation
    'faucetpay' => [
        'name' => 'FaucetPay',
        'currencies' => ['BTC','LTC','DOGE','ETH'],
        'api_base' => 'https://faucetpay.io/api/v1/',
        'check' => 'https://faucetpay.io/page/user-admin',
        'url' => 'https://gr8.cc/goto/faucetpay'
    ],
    // https://kswallet.net/documentation
    'kswallet' => [
        'name' => 'KSWallet',
        'currencies' => ['BTC','DGB','EOS','ETC','LSK','LTC','QTUM','STRAT','ZEC'],
        'api_base' => 'https://www.kswallet.net/api/',
        'check' => 'https://kswallet.net/dashboard',
        'url' => 'https://gr8.cc/goto/kswallet',
        'placeholder' => 'Enter your KSWallet Address'
    ],
    // https://microwallet.co/docs
    'microwallet' => [
        'name' => 'Microwallet',
        'currencies' => ['BCH','BTC','DOGE','ETH','LTC'],
        'api_base' => 'https://api.microwallet.co/v1/',
        'check' => 'https://microwallet.co/dashboard',
        'url' => 'https://gr8.cc/goto/microwallet'
    ],
    // https://www.walcrypt.com/api-doc/
    'walcrypt' => [
        'name' => 'WalCrypt',
        'currencies' => ['BCH','BTC','DASH','DOGE','ETH','LTC','XMR','XRP'],
        'api_base' => 'https://walcrypt.com/api/v1/',
        'check' => 'https://www.walcrypt.com/dashboard/',
        'url' => 'https://gr8.cc/goto/walcrypt'
    ]
];