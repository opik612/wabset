
GR8 Faucet Script Lite
https://gr8.cc

Copyright 2019 GR8 Scripts, AvalonRychmon

GR8 Faucet Script Lite is free bare bones version of the GR8 Faucet Script.
It was released so that anyone interested in operating a cryptocurrecy faucet
would have an equal opportunity regardless of their financial position or
personal knowledge of coding. 

If you need assistance with this script, then please join us on Discord at
https://discordapp.com/invite/DeExBQJ

I personally wish you great success on your journey! -AvalonRychmon




INSTALL INSTRUCTIONS: 
- Open config.php (Add your database login details)
- Change permissions for "libs/cache" folder to 777
- Access your Faucet Domain from your browser
- You should be redirected to your admin panel (Password is the same as Database Password)